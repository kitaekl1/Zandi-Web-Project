package com.assey.zandi.account;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "kakao_users")
public class KakaoUserVO {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "kakao_users_seq")
    @SequenceGenerator(name = "kakao_users_seq", sequenceName = "kakao_users_seq", allocationSize = 1)
    private Long id;

    @Column(name = "kakao_id", nullable = false, unique = true)
    private Long kakaoId;

    @Column(nullable = false)
    private String nickname;

    @Column(name = "profile_image")
    private String profileImage;

    @Column(name = "status")
    private String status;

    @Column(name = "registered_at")
    private Timestamp registeredAt;

    @Column(name = "created_at")
    private Timestamp createdAt;


    // Constructor
    public KakaoUserVO() {
        this.status = "ACTIVE"; // 기본값 설정
        this.registeredAt = new Timestamp(System.currentTimeMillis()); // 기본값 설정
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getKakaoId() {
        return kakaoId;
    }

    public void setKakaoId(Long kakaoId) {
        this.kakaoId = kakaoId;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getProfileImage() {
        return profileImage;
    }

    public void setProfileImage(String profileImage) {
        this.profileImage = profileImage;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getRegisteredAt() {
        return registeredAt;
    }

    public void setRegisteredAt(Timestamp registeredAt) {
        this.registeredAt = registeredAt;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }


    @PrePersist
    protected void onCreate() {
        this.createdAt = new Timestamp(System.currentTimeMillis());
    }


}