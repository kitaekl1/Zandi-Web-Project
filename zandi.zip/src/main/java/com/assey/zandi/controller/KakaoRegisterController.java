package com.assey.zandi.controller;

import com.assey.zandi.repository.CfmemberRepository;
import com.assey.zandi.account.CfmemberVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/zandi")
public class KakaoRegisterController {

    @Autowired
    private CfmemberRepository memberRepository;

    @PostMapping("/kakaoRegister")
    public String register(CfmemberVO member, HttpSession session) {
        Long kakaoId = (Long) session.getAttribute("kakaoId");
        if (kakaoId == null) {
            return "redirect:/zandi/login";
        }

        
        member.setMemId(kakaoId.toString());
        member.setMemNickname((String) session.getAttribute("kakaoNickname"));

       
        memberRepository.save(member);

      
        session.setAttribute("loginID", member.getMemId());

        return "redirect:/zandiMainPage/MainPage.jsp";
    }
}