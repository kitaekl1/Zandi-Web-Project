package com.assey.zandi.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.assey.zandi.project.AttachImageVO;
import com.assey.zandi.project.ProjectVO;
import com.assey.zandi.service.AdminService;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/zandi")
public class AdminController {
    private static final Logger logger = LoggerFactory.getLogger(AdminController.class);

    @Autowired
    private AdminService adminService;

    @GetMapping("/addProjectForm")
    public String addProjectForm() {
        logger.info("이미지업로드..");
        return "/zandiBookmark/addProjectForm";  
    }

    @PostMapping(value = "/uploadAjaxAction", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ResponseBody
    public ResponseEntity<List<AttachImageVO>> uploadAjaxActionPost(@RequestParam("uploadfile") MultipartFile[] uploadFile, HttpServletRequest request) {
        logger.info("uploadAjaxActionPOST...");
        String uploadFolder = "C:/Users/User/Desktop/Zandi-Web-Project/zandi/src/main/webapp/resources/upload";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");

        Date date = new Date();
        String str = sdf.format(date);
        String datePath = str.replace("/", File.separator);

        File uploadPath = new File(uploadFolder, datePath);
        if (!uploadPath.exists()) {
            uploadPath.mkdirs();
        }

        List<AttachImageVO> list = new ArrayList<>();
        for (MultipartFile multipartFile : uploadFile) {
            String uploadFileName = multipartFile.getOriginalFilename();
            String uuid = UUID.randomUUID().toString();
            uploadFileName = uuid + "_" + uploadFileName;
            File saveFile = new File(uploadPath, uploadFileName);

            AttachImageVO vo = new AttachImageVO();
            vo.setFileName(uploadFileName);
            vo.setUploadPath(datePath);  
            vo.setUuid(uuid);
            try {
                multipartFile.transferTo(saveFile);

                File thumbnailFile = new File(uploadPath, "s_" + uploadFileName);
                BufferedImage bo_image = ImageIO.read(saveFile);
                double ratio = 3.0;
                int width = (int) (bo_image.getWidth() / ratio);
                int height = (int) (bo_image.getHeight() / ratio);
                BufferedImage bt_image = new BufferedImage(width, height, BufferedImage.TYPE_3BYTE_BGR);
                Graphics2D graphic = bt_image.createGraphics();
                graphic.drawImage(bo_image, 0, 0, width, height, null);
                graphic.dispose();  
                ImageIO.write(bt_image, "jpg", thumbnailFile);

            } catch (IOException e) {
                logger.error("File upload error", e);
                return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
            list.add(vo);
        }

        return new ResponseEntity<>(list, HttpStatus.OK);
    }




    @PostMapping("/addProjectForm")
    public String projectRegi(ProjectVO proj, @RequestParam("prImg") MultipartFile file, RedirectAttributes rttr, HttpSession session, HttpServletRequest request) {
       
        String loginID = (String) session.getAttribute("loginID");
        if (loginID == null) {
            logger.error("User not logged in.");
            return "redirect:/zandi/login";
        }
        proj.setPrId(loginID);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");
        Timestamp startDate = Timestamp.valueOf(LocalDateTime.parse(proj.getPrStartdate(), formatter));
        Timestamp endDate = Timestamp.valueOf(LocalDateTime.parse(proj.getPrEnddate(), formatter));

        proj.setPrStartdate(startDate.toString());
        proj.setPrEnddate(endDate.toString());

        logger.info("Converted Start Date: " + startDate);
        logger.info("Converted End Date: " + endDate);

        if (!file.isEmpty()) {
            String uploadFolder = request.getServletContext().getRealPath("/resources/upload/");
            String uploadFileName = UUID.randomUUID().toString() + "_" + file.getOriginalFilename();
            String datePath = new SimpleDateFormat("yyyy/MM/dd").format(new Date()).replace("/", File.separator);
            File saveDir = new File(uploadFolder + File.separator + datePath);
            if (!saveDir.exists()) {
                saveDir.mkdirs();
            }
            File saveFile = new File(saveDir, uploadFileName);
            try {
                file.transferTo(saveFile);
                logger.info("File uploaded successfully: " + saveFile.getAbsolutePath());
                proj.setPrImg("resources/upload/" + datePath + "/" + uploadFileName);
            } catch (IOException e) {
                logger.error("File upload error", e);
                rttr.addFlashAttribute("message", "File upload failed.");
                return "redirect:/zandi/addProjectForm";
            }
        } else {
            logger.error("No file uploaded.");
            rttr.addFlashAttribute("message", "No file uploaded.");
            return "redirect:/zandi/addProjectForm";
        }

        adminService.projRegi(proj);
        rttr.addFlashAttribute("enroll_result", proj.getPrName());

        return "redirect:/zandi/MainPage"; 
    }

}