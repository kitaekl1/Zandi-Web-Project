package com.assey.zandi.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.assey.zandi.project.AttachImageVO;
import com.assey.zandi.project.ProjectVO;
import com.assey.zandi.service.AdminService;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/zandi")
public class AdminController {
    private static final Logger logger = LoggerFactory.getLogger(AdminController.class);

    @Autowired
    private AdminService adminService;

    @GetMapping("/addProjectForm")
    public String addProjectForm() {
        logger.info("프로젝트 등록 페이지로 이동..");
        return "/zandiBookmark/addProjectForm";  // JSP 파일의 경로 반환
    }
    
    @PostMapping(value="/uploadAjaxAction", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ResponseBody
    public ResponseEntity<List<AttachImageVO>> uploadAjaxActionPost(@RequestParam("uploadfile") MultipartFile[] uploadFile) {
        logger.info("uploadAjaxActionPOST...");
        String uploadFolder = "C:\\upload";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        Date date = new Date();
        String str = sdf.format(date);
        String datePath = str.replace("-", File.separator);

        File uploadPath = new File(uploadFolder, datePath);
        if (!uploadPath.exists()) {
            uploadPath.mkdirs();
        }
        List<AttachImageVO> list = new ArrayList();
        for (MultipartFile multipartFile : uploadFile) {
            String uploadFileName = multipartFile.getOriginalFilename();
            String uuid = UUID.randomUUID().toString();
            uploadFileName = uuid + "_" + uploadFileName;
            File saveFile = new File(uploadPath, uploadFileName);
            //이미지 정보를 담는 객체
            AttachImageVO vo = new AttachImageVO();
            vo.setFileName(uploadFileName);
            vo.setUploadPath(datePath);
            vo.setUuid(uuid);
            try {
                multipartFile.transferTo(saveFile);
                File thumbnailFile = new File(uploadPath, "s_" + uploadFileName);
                BufferedImage bo_image = ImageIO.read(saveFile);
                double ratio = 3;
                int width = (int) (bo_image.getWidth() / ratio);
                int height = (int) (bo_image.getHeight() / ratio);
                BufferedImage bt_image = new BufferedImage(width, height, BufferedImage.TYPE_3BYTE_BGR);
                Graphics2D graphic = bt_image.createGraphics();
                graphic.drawImage(bo_image, 0, 0, width, height, null);
                ImageIO.write(bt_image, "jpg", thumbnailFile);
            } catch (Exception e) {
                e.printStackTrace();
                
            }
            list.add(vo);
        }
        
        ResponseEntity<List<AttachImageVO>> result = new ResponseEntity<List<AttachImageVO>>(list, HttpStatus.OK);
        return result;
    }
    
    
    @PostMapping("/addProjectForm")
    public String projectRegi(ProjectVO proj, @RequestParam("prImg") MultipartFile file, RedirectAttributes rttr, HttpSession session) {

        // 세션에서 로그인 ID를 가져와 prId에 설정
        String loginID = (String) session.getAttribute("loginID");
        if (loginID == null) {
            logger.error("로그인된 사용자의 ID를 가져오지 못했습니다.");
            return "redirect:/zandi/login";
        }
        proj.setPrId(loginID);

        // 문자열을 Timestamp로 변환
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");
        Timestamp startDate = Timestamp.valueOf(LocalDateTime.parse(proj.getPrStartdate(), formatter));
        Timestamp endDate = Timestamp.valueOf(LocalDateTime.parse(proj.getPrEnddate(), formatter));

        proj.setPrStartdate(startDate.toString());
        proj.setPrEnddate(endDate.toString());

        logger.info("Converted Start Date: " + startDate);
        logger.info("Converted End Date: " + endDate);

      

        adminService.projRegi(proj);

        rttr.addFlashAttribute("enroll_result", proj.getPrName());

        return "redirect:/zandiMainPage/MainPage.jsp"; 
    }
}
