package com.assey.zandi.repository;

import com.assey.zandi.project.ProjectVO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProjectRepository extends JpaRepository<ProjectVO, Integer> {
    Page<ProjectVO> findByPrNameContainingOrPrDescriptionContaining(String prName, String prDescription, Pageable pageable);
    long countByPrNameContainingOrPrDescriptionContaining(String prName, String prDescription);

    Page<ProjectVO> findByPrCategory(String prCategory, Pageable pageable);
    long countByPrCategory(String prCategory);
}
