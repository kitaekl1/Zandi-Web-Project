package com.assey.zandi.repository;

import com.assey.zandi.account.KakaoUserVO;
import org.springframework.data.jpa.repository.JpaRepository;

public interface KakaoUserRepository extends JpaRepository<KakaoUserVO, Long> {
    KakaoUserVO findByKakaoId(Long kakaoId);
}