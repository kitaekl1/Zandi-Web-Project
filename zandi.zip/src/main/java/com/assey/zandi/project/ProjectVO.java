package com.assey.zandi.project;

import com.assey.zandi.account.KakaoUserVO;

import javax.persistence.*;

@Entity
@Table(name = "cf_project")
public class ProjectVO {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int prCode;

    private String prName;
    private String prDescription;
    private String prTeam;
    private String prId; 

    private String prCategory;
    private int prGoal;
    private int prCurrent = 0;
    private int prLikecount = 0;
    private String prStartdate;
    private String prEnddate;

    private String prImg; 

   

    public String getPrImg() {
        return prImg;
    }

    public void setPrImg(String prImg) {
        this.prImg = prImg;
    }



    // Getters and Setters
    public int getPrCode() {
        return prCode;
    }

    public void setPrCode(int prCode) {
        this.prCode = prCode;
    }

    public String getPrName() {
        return prName;
    }

    public void setPrName(String prName) {
        this.prName = prName;
    }

    public String getPrDescription() {
        return prDescription;
    }

    public void setPrDescription(String prDescription) {
        this.prDescription = prDescription;
    }

    public String getPrTeam() {
        return prTeam;
    }

    public void setPrTeam(String prTeam) {
        this.prTeam = prTeam;
    }

    public String getPrId() {
        return prId;
    }

    public void setPrId(String prId) {
        this.prId = prId;
    }

    public String getPrCategory() {
        return prCategory;
    }

    public void setPrCategory(String prCategory) {
        this.prCategory = prCategory;
    }

    public int getPrGoal() {
        return prGoal;
    }

    public void setPrGoal(int prGoal) {
        this.prGoal = prGoal;
    }

    public int getPrCurrent() {
        return prCurrent;
    }

    public void setPrCurrent(int prCurrent) {
        this.prCurrent = prCurrent;
    }

    public int getPrLikecount() {
        return prLikecount;
    }

    public void setPrLikecount(int prLikecount) {
        this.prLikecount = prLikecount;
    }

    public String getPrStartdate() {
        return prStartdate;
    }

    public void setPrStartdate(String prStartdate) {
        this.prStartdate = prStartdate;
    }

    public String getPrEnddate() {
        return prEnddate;
    }

    public void setPrEnddate(String prEnddate) {
        this.prEnddate = prEnddate;
    }


    public void incrementLikecount() {
        this.prLikecount++;
    }

    public void decrementLikecount() {
        if (this.prLikecount > 0) {
            this.prLikecount--;
        }
    }
}