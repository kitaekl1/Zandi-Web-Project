package com.assey.zandi.util;

public class ConstVariable {
	
	public static final String UPLOAD_PATH = "C:\\SpringWS\\zandi\\src\\main\\resources\\static\\upload\\";
}
