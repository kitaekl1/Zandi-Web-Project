package com.assey.zandi;
import com.zandi.account.CfmemberVO;
public interface cfmember {
	public void memberJoin(CfmemberVO cfmember);
}
