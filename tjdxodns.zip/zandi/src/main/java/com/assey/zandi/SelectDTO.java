package com.assey.zandi;

public class SelectDTO {

}
