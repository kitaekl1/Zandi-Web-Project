package com.zandi.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.assey.zandi.CateVO;
import com.assey.zandi.ProjectVO;




@Mapper
public interface AdminMapper {
	public void projRegi(ProjectVO proj);
	public List<CateVO> cateList();
}
