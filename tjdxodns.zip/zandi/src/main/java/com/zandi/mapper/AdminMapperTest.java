package com.zandi.mapper;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.assey.zandi.ProjectVO;

import static org.junit.Assert.assertNotNull;

import java.sql.Timestamp;
import java.time.LocalDateTime;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/main/resources/mybatis/mapper/root-context.xml" }) // XML 설정 파일 경로
public class AdminMapperTest {

    @Autowired
    private AdminMapper mapper;
    @Test
    @Rollback(false)
    public void projRegiTest() throws Exception {
       ProjectVO proj = new ProjectVO();
    	   
    	   	proj.setPrCode(1);
       		proj.setPrName("테스트");
       		proj.setPrDescription("테스트용프로젝트입니다.");
       		proj.setPrTeam("테스트팀");
       		proj.setPrId("deneb14");
       		proj.setPrCategory("애니메이션");
       		proj.setPrCategoryCode("105");
       		proj.setPrGoal("50000");
       		proj.setPrCurrent("0");
       		proj.setPrLikecount(0);
       		proj.setPrStartdate(new Timestamp(System.currentTimeMillis()));
            proj.setPrEnddate(new Timestamp(System.currentTimeMillis() + 86400000)); // 현재 시간 + 1일

       		
       		mapper.projRegi(proj);
    }
}
