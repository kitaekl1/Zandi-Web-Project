package com.zandi.controller;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.assey.zandi.ProjectVO;
import com.zandi.service.AdminService;

@Controller
@RequestMapping("/admin")
public class AdminController {
	private static final Logger logger = LoggerFactory.getLogger(AdminController.class);

	@Autowired
	private AdminService adminService;
	
	@RequestMapping(value ="addProject", method = RequestMethod.GET)
	public void addProjectGET() throws Exception{
		logger.info("프로젝트 등록페이지로 이동..");
	}
	
	@PostMapping("/projectRegi")
	public String projectRegi(ProjectVO proj, RedirectAttributes rttr) {
		
		logger.info("projectRegiPOST......" + proj);
		
		adminService.projRegi(proj);
		
		rttr.addFlashAttribute("enroll_result", proj.getPrName());
		
		return "redirect:/admin/addProjectForm";
	}	
}
