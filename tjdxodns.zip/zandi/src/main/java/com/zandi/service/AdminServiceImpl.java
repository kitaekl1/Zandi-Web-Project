package com.zandi.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assey.zandi.ProjectVO;
import com.zandi.mapper.AdminMapper;


import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class AdminServiceImpl implements AdminService{
	@Autowired
	private AdminMapper adminMapper;	
	
	/* 상품 등록 */
	@Override
	public void projRegi(ProjectVO proj) {
		
		log.info("(srevice)projRegi........");
		
		adminMapper.projRegi(proj);
		
	}
}
