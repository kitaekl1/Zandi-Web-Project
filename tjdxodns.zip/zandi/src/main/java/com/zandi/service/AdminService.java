package com.zandi.service;

import com.assey.zandi.ProjectVO;

public interface AdminService {
	public void projRegi(ProjectVO proj);
}
