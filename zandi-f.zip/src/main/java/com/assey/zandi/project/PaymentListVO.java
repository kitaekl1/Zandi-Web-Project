package com.assey.zandi.project;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.assey.zandi.account.CfmemberVO;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "payment_list")
public class PaymentListVO {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "payment_list_id")
    private Long id; // PK
 
    @ManyToOne
    @JoinColumn(name = "member", nullable = false)
    private CfmemberVO member; // 사용자
 
    @ManyToOne
    @JoinColumn(name = "payments", nullable = false)
    private PaymentVO payments; // 주문 테이블과 다대일 (연관관계 주인은 주문)
 
    @ManyToOne
    @JoinColumn(name = "project", nullable = false)
    private ProjectVO project; // 상품 
 
    @Column(name = "project_name")
    private String projectName; // 상품 이름
 
    @Column(name = "project_price", nullable = false)
    private Long price; // 가격
 
    @Column(name = "paid_at", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private LocalDateTime paidAt; // 결제시각
 
    @Column(name = "status")
    private Boolean status = true; // 상태
 
    public PaymentListVO(CfmemberVO member, PaymentVO payments, ProjectVO project, String projectName, Long price) {
        this.member = member;
        this.payments = payments;
        this.project = project;
        this.projectName = projectName;
        this.price = price;
        this.paidAt =  LocalDateTime.now();
    }
}
