package com.assey.zandi.project;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "cf_order")
public class OrderDTO {

	private String orderUid;
    private String prCode;
    private String Name;
    private Long paymentAmount;
    private String buyerEmail;
    private String buyerAddress;	
    
    @Builder
    public RequestPayDto(String orderUid, String itemName, String buyerName, Long paymentPrice, String buyerEmail, String buyerAddress) {
        this.orderUid = orderUid;
        this.itemName = itemName;
        this.buyerName = buyerName;
        this.paymentPrice = paymentPrice;
        this.buyerEmail = buyerEmail;
        this.buyerAddress = buyerAddress;
    }
}