package com.assey.zandi.service;

import okhttp3.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.assey.zandi.project.PaymentVO;

import java.io.IOException;

public class PortOneService {
	
    private final OkHttpClient httpClient = new OkHttpClient();

    @Value("${portone.api.key}")
    private String apiKey;

    @Value("${portone.api.secret}")
    private String apiSecret;

    public String getToken() throws IOException {
        RequestBody body = new FormBody.Builder()
                .add("imp_key", apiKey)
                .add("imp_secret", apiSecret)
                .build();

        Request request = new Request.Builder()
                .url("https://api.iamport.kr/users/getToken")
                .post(body)
                .build();

        try (Response response = httpClient.newCall(request).execute()) {
            if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);

            return response.body().string();
        }
    }

    public String requestPayment(String token, PaymentVO paymentRequest) throws IOException {
        RequestBody body = RequestBody.create(
                MediaType.parse("application/json; charset=utf-8"),
                paymentRequest.toJson()
        );

        Request request = new Request.Builder()
                .url("https://api.iamport.kr/payments/request")
                .addHeader("Authorization", token)
                .post(body)
                .build();

        try (Response response = httpClient.newCall(request).execute()) {
            if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);

            return response.body().string();
        }
    }
}
