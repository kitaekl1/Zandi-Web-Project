package com.assey.zandi.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.assey.zandi.project.ProjectVO;
import com.assey.zandi.mapper.AdminMapper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Service
public class AdminServiceImpl implements AdminService {
    private static final Logger log = LogManager.getLogger(AdminServiceImpl.class);

    @Autowired
    private AdminMapper adminMapper;

    @Override
    public void projRegi(ProjectVO proj) {
        log.info("(service)projRegi........");
        // 프로젝트 시작일 및 종료일을 null이 아닌 값으로 설정하도록 보장
        if (proj.getPrStartdate() == null || proj.getPrEnddate() == null) {
            throw new IllegalArgumentException("프로젝트 시작일 또는 종료일이 설정되지 않았습니다.");
        }
        adminMapper.projRegi(proj);
    }
}