package com.assey.zandi.service;

import com.assey.zandi.bookmark.LikelistVO;
import com.assey.zandi.project.ProjectVO;
import com.assey.zandi.repository.BookmarkRepository;
import com.assey.zandi.repository.ProjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class BookmarkServiceImpl implements BookmarkService {

    @Autowired
    private BookmarkRepository bookmarkRepository;

    @Autowired
    private ProjectRepository projectRepository;

    @Override
    public List<ProjectVO> getBookmarkedProjects(String loginID, int startRow, int pageSize) {
        Pageable pageable = PageRequest.of(startRow / pageSize, pageSize);
        return bookmarkRepository.findBookmarkedProjectsByUserId(loginID, pageable);
    }

    @Override
    public int getBookmarkedProjectCount(String loginID) {
        return bookmarkRepository.countBookmarkedProjectsByUserId(loginID);
    }

    @Override
    @Transactional
    public void deleteBookmark(int prCode, String loginID) {
        bookmarkRepository.deleteByPrCodeAndMId(prCode, loginID);

        // 프로젝트의 prLikecount 감소
        ProjectVO project = projectRepository.findById(prCode).orElse(null); // Integer 타입 사용
        if (project != null && project.getPrLikecount() > 0) {
            project.decrementLikecount();
            projectRepository.save(project); // 수정된 프로젝트 저장
        }
    }

    @Override
    @Transactional
    public boolean toggleBookmark(String loginID, int prCode) {
        LikelistVO existingBookmark = bookmarkRepository.findByMemIdAndPrCode(loginID, prCode);

        if (existingBookmark != null) {
            // 이미 북마크가 있는 경우 -> 삭제
            bookmarkRepository.delete(existingBookmark);
            ProjectVO project = projectRepository.findById(prCode).orElse(null); // Integer 타입 사용
            if (project != null) {
                project.decrementLikecount();
                projectRepository.save(project); // 수정된 프로젝트 저장
            }
            return false;
        } else {
            // 북마크가 없는 경우 -> 추가
            LikelistVO newBookmark = new LikelistVO();
            LikelistVO.LikelistId bookmarkId = new LikelistVO.LikelistId();
            bookmarkId.setMemId(loginID);
            bookmarkId.setPrCode(prCode);
            newBookmark.setId(bookmarkId);
            bookmarkRepository.save(newBookmark);
            ProjectVO project = projectRepository.findById(prCode).orElse(null); // Integer 타입 사용
            if (project != null) {
                project.incrementLikecount();
                projectRepository.save(project); // 수정된 프로젝트 저장
            }
            return true;
        }
    }

    @Override
    public List<Integer> getUserBookmarkedProjectCodes(String loginID) {
        return bookmarkRepository.findBookmarkedProjectCodesByUserId(loginID);
    }

    @Override
    public List<ProjectVO> getBookmarkedProjectsForUser(String loginID) {
        List<Integer> bookmarkedProjectCodes = bookmarkRepository.findBookmarkedProjectCodesByUserId(loginID);
        return bookmarkedProjectCodes.stream()
                .map(prCode -> projectRepository.findById(prCode).orElse(null)) // Integer 타입 사용
                .filter(project -> project != null)
                .collect(Collectors.toList());
    }

    @Override
    public List<ProjectVO> getUserBookmarkedProjects(String loginID) {
        List<Integer> bookmarkedProjectCodes = bookmarkRepository.findBookmarkedProjectCodesByUserId(loginID);
        return bookmarkedProjectCodes.stream()
                .map(prCode -> projectRepository.findById(prCode).orElse(null))
                .filter(project -> project != null)
                .collect(Collectors.toList());
    }
}