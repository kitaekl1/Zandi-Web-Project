package com.assey.zandi.service;

import com.assey.zandi.project.ProjectVO;
import com.assey.zandi.repository.ProjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProjectService {

    @Autowired
    private ProjectRepository projectRepository;

    public List<ProjectVO> searchProjects(String searchText, int offset, int limit) {
        Pageable pageable = PageRequest.of(offset / limit, limit);
        Page<ProjectVO> projectPage = projectRepository.findByPrNameContainingOrPrDescriptionContaining(searchText, searchText, pageable);
        return projectPage.getContent();
    }

    public int countSearchProjects(String searchText) {
        return (int) projectRepository.countByPrNameContainingOrPrDescriptionContaining(searchText, searchText);
    }
    
    public List<ProjectVO> findProjectsByUsername(String loginID) {
        return projectRepository.findByPrId(loginID);
    }

    // 페이징 처리된 사용자별 프로젝트 조회 메서드
    public List<ProjectVO> findProjectsByUsername(String loginID, int offset, int limit) {
        Pageable pageable = PageRequest.of(offset / limit, limit);
        Page<ProjectVO> projectPage = projectRepository.findByPrId(loginID, pageable);
        return projectPage.getContent();
    }

    public int countProjectsByUsername(String loginID) {
        return (int) projectRepository.countByPrId(loginID);
    }
    
    // 프로젝트 삭제 메서드
    public void deleteProject(int prCode, String prId) {
        projectRepository.deleteByPrCodeAndPrId(prCode, prId);
    }
    
    // 모든 프로젝트를 조회하는 메서드 추가
    public List<ProjectVO> getAllProjects() {
        return projectRepository.findAll();
    }
    
    
    
    public List<ProjectVO> getAllProjects(int offset, int limit) {
        Pageable pageable = PageRequest.of(offset / limit, limit);
        Page<ProjectVO> projectPage = projectRepository.findAll(pageable);
        return projectPage.getContent();
    }


    
    // prCode로 프로젝트를 조회하는 메서드 추가
    public ProjectVO getProjectByPrCode(int prCode) {
        return projectRepository.findById(prCode).orElse(null);
    }
    
    public List<ProjectVO> getProjectsByCategory(String category, int offset, int limit) {
        Pageable pageable = PageRequest.of(offset / limit, limit);
        Page<ProjectVO> projectPage = projectRepository.findByPrCategory(category, pageable);
        return projectPage.getContent();
    }
    
    public int countAllProjects() {
        return (int) projectRepository.count();
    }
    
    
    public int countProjectsByCategory(String category) {
        return (int) projectRepository.countByPrCategory(category);
    }
    
}
