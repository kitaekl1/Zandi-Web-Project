package com.assey.zandi.service;

import com.assey.zandi.account.KakaoUserVO;
import com.assey.zandi.repository.KakaoUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class KakaoUserService {

    @Autowired
    private KakaoUserRepository kakaoUserRepository;

    public KakaoUserVO saveOrUpdateUser(KakaoUserVO kakaoUser) {
        KakaoUserVO existingUser = kakaoUserRepository.findByKakaoId(kakaoUser.getKakaoId());
        if (existingUser != null) {
            existingUser.setNickname(kakaoUser.getNickname());
            existingUser.setProfileImage(kakaoUser.getProfileImage());
            return kakaoUserRepository.save(existingUser);
        } else {
            return kakaoUserRepository.save(kakaoUser);
        }	
    }

    public KakaoUserVO findByKakaoId(Long kakaoId) {
        return kakaoUserRepository.findByKakaoId(kakaoId);
    }
}