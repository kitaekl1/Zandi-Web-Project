package com.assey.zandi.controller;

import com.assey.zandi.repository.CfmemberRepository;
import com.assey.zandi.account.CfmemberVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/zandi")
public class KakaoRegisterController {

    @Autowired
    private CfmemberRepository memberRepository;

    @PostMapping("/kakaoRegister")
    public String register(CfmemberVO member, HttpSession session) {
        Long kakaoId = (Long) session.getAttribute("kakaoId");
        if (kakaoId == null) {
            return "redirect:/zandi/login";
        }

        // 세션에서 가져온 카카오 정보를 멤버 객체에 설정
        member.setMemId(kakaoId.toString());
        member.setMemNickname((String) session.getAttribute("kakaoNickname"));

        // 회원 정보를 데이터베이스에 저장
        memberRepository.save(member);

        // 세션에 로그인 ID 설정
        session.setAttribute("loginID", member.getMemId());

        return "redirect:/zandiMainPage/MainPage.jsp";
    }
}