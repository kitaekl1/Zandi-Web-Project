package com.assey.zandi.controller;

import com.assey.zandi.account.CfmemberVO;
import com.assey.zandi.repository.CfmemberRepository;
import com.assey.zandi.repository.KakaoUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Map;
import java.util.logging.Logger;

import javax.servlet.http.HttpSession;

@Controller
public class KakaoLoginController {

    private static final Logger logger = Logger.getLogger(KakaoLoginController.class.getName());

    private final RestTemplate restTemplate;
    private final KakaoUserRepository userRepository;
    private final CfmemberRepository memberRepository;

    @Value("${kakao.api_key}")
    private String kakaoRestApiKey;

    @Value("${kakao.redirect_uri}")
    private String kakaoRedirectUri;
    
    @Autowired
    public KakaoLoginController(RestTemplate restTemplate, KakaoUserRepository userRepository, CfmemberRepository memberRepository) {
        this.restTemplate = restTemplate;
        this.userRepository = userRepository;
        this.memberRepository = memberRepository;
    }

    @GetMapping("/kakaoCallback")
    public String kakaoCallback(@RequestParam String code, HttpSession session, RedirectAttributes redirectAttributes) {

        try {
            // 액세스 토큰 요청
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

            MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
            params.add("grant_type", "authorization_code");
            params.add("client_id", kakaoRestApiKey);
            params.add("redirect_uri", kakaoRedirectUri);
            params.add("code", code);

            HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(params, headers);

            ResponseEntity<Map> response = restTemplate.exchange(
                "https://kauth.kakao.com/oauth/token",
                HttpMethod.POST,
                entity,
                Map.class
            );


            if (response.getStatusCode() == HttpStatus.OK) {
                String accessToken = (String) response.getBody().get("access_token");

                // 액세스 토큰 유효성 확인
                String tokenInfoUrl = "https://kapi.kakao.com/v1/user/access_token_info";
                HttpHeaders tokenInfoHeaders = new HttpHeaders();
                tokenInfoHeaders.set("Authorization", "Bearer " + accessToken);
                HttpEntity<String> tokenInfoEntity = new HttpEntity<>(tokenInfoHeaders);


                ResponseEntity<String> tokenInfoResponse = restTemplate.exchange(
                    tokenInfoUrl,
                    HttpMethod.GET,
                    tokenInfoEntity,
                    String.class
                );


                if (tokenInfoResponse.getStatusCode() != HttpStatus.OK) {
                    redirectAttributes.addAttribute("error", "token");
                    return "redirect:/zandi/login";
                }

                // 사용자 정보 요청
                headers = new HttpHeaders();
                headers.set("Authorization", "Bearer " + accessToken);
                entity = new HttpEntity<>(headers);

                ResponseEntity<Map> userResponse = restTemplate.exchange(
                    "https://kapi.kakao.com/v2/user/me",
                    HttpMethod.GET,
                    entity,
                    Map.class
                );

                if (userResponse.getStatusCode() == HttpStatus.OK) {
                    Map<String, Object> kakaoProfile = userResponse.getBody();

                    Long kakaoId = Long.valueOf(String.valueOf(kakaoProfile.get("id")));

                    // 기존 사용자 확인
                    CfmemberVO existingMember = memberRepository.findMemberByMemId(kakaoId.toString());
                    if (existingMember != null) {
                        session.setAttribute("loginID", existingMember.getMemId());
                        return "redirect:/zandiMainPage/MainPage.jsp";
                    } else {
                        // 세션에 카카오 사용자 정보를 저장하고 추가 정보 입력 폼으로 리디렉션
                        session.setAttribute("kakaoId", kakaoId);
                        session.setAttribute("kakaoNickname", ((Map<String, Object>) ((Map<String, Object>) kakaoProfile.get("kakao_account")).get("profile")).get("nickname"));
                        return "redirect:/zandiaccount/kakaoRegister.jsp";
                    }
                } else {
                    logger.warning("Failed to get Kakao profile");
                    redirectAttributes.addAttribute("error", "profile");
                    return "redirect:/zandi/login";
                }
            } else {
                logger.warning("Failed to get access token");
                redirectAttributes.addAttribute("error", "token");
                return "redirect:/zandi/login";
            }
        } catch (Exception e) {
            logger.severe("Exception during Kakao login callback: " + e.getMessage());
            redirectAttributes.addAttribute("error", "exception");
            return "redirect:/zandi/login";
        }
    }
}