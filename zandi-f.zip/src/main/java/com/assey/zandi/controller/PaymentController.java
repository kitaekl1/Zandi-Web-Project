package com.assey.zandi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import com.assey.zandi.mapper.AdminMapper;
import com.assey.zandi.project.OrderDTO;

import lombok.RequiredArgsConstructor;

import java.io.IOException;
import java.util.Map;

import javax.servlet.http.HttpSession;

@RestController
@RequestMapping("/payment")
@RequiredArgsConstructor
public class PaymentController {
	private final PaymentService orderService;
    private final HttpSession httpSession;
    private final AdminMapper modelMapper;
 
    @PostMapping("/done")
    public ResponseEntity<Object> completeOrder(@RequestBody OrderDTO request) {
 
        OrderDTO orders = modelMapper.map(request, OrderDTO.class);
 
        // 세션에서 임시 주문 정보를 가져옴
        Orders temporaryOrder = (Orders) httpSession.getAttribute("temporaryOrder");
 
        if (temporaryOrder == null) {
            return ResponseEntity.badRequest().body("임시 주문 정보를 찾을 수 없습니다.");
        }
 
        Orders completedOrder = orderService.orderConfirm(temporaryOrder, orders);
 
        OrderResponseDto orderResponseDto = new OrderResponseDto(completedOrder);
 
        return ResponseEntity.ok(orderResponseDto);
 
    }
}
