package com.assey.zandi.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.assey.zandi.project.AttachImageVO;
import com.assey.zandi.project.ProjectVO;
import com.assey.zandi.service.AdminService;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/zandi")
public class AdminController {
    private static final Logger logger = LoggerFactory.getLogger(AdminController.class);

    @Autowired
    private AdminService adminService;

    @GetMapping("/addProjectForm")
    public String addProjectForm() {
        logger.info("프로젝트 등록 페이지로 이동..");
        return "/zandiBookmark/addProjectForm";  // JSP 파일의 경로 반환
    }

    @PostMapping(value="/uploadAjaxAction", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ResponseBody
    public ResponseEntity<List<AttachImageVO>> uploadAjaxActionPost(@RequestParam("uploadfile") MultipartFile[] uploadFile, HttpServletRequest request) {
        logger.info("uploadAjaxActionPOST...");
        String uploadFolder = request.getServletContext().getRealPath("/resources/upload/");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");

        Date date = new Date();
        String str = sdf.format(date);
        String datePath = str.replace("/", File.separator);

        File uploadPath = new File(uploadFolder, datePath);
        if (!uploadPath.exists()) {
            uploadPath.mkdirs();
        }
        List<AttachImageVO> list = new ArrayList<>();
        for (MultipartFile multipartFile : uploadFile) {
            String uploadFileName = multipartFile.getOriginalFilename();
            String uuid = UUID.randomUUID().toString();
            uploadFileName = uuid + "_" + uploadFileName;
            File saveFile = new File(uploadPath, uploadFileName);
            // 이미지 정보를 담는 객체
            AttachImageVO vo = new AttachImageVO();
            vo.setFileName(uploadFileName);
            vo.setUploadPath(datePath);  // /upload/ 부분을 포함하지 않음
            vo.setUuid(uuid);
            try {
                multipartFile.transferTo(saveFile);
                
                // 썸네일 생성
                File thumbnailFile = new File(uploadPath, "s_" + uploadFileName);
                BufferedImage bo_image = ImageIO.read(saveFile);
                double ratio = 5.0;
                int width = (int) (bo_image.getWidth() / ratio);
                int height = (int) (bo_image.getHeight() / ratio);
                BufferedImage bt_image = new BufferedImage(width, height, BufferedImage.TYPE_3BYTE_BGR);
                Graphics2D graphic = bt_image.createGraphics();
                graphic.drawImage(bo_image, 0, 0, width, height, null);
                graphic.dispose();  // 리소스 해제
                ImageIO.write(bt_image, "jpg", thumbnailFile);
                
            } catch (Exception e) {
                e.printStackTrace();
            }
            list.add(vo);
        }

        ResponseEntity<List<AttachImageVO>> result = new ResponseEntity<>(list, HttpStatus.OK);
        return result;
    }

    @PostMapping("/addProjectForm")
    public String projectRegi(ProjectVO proj, @RequestParam("prImg") MultipartFile[] files, RedirectAttributes rttr, HttpSession session, HttpServletRequest request) {
        // 세션에서 로그인 ID를 가져와 prId에 설정
        String loginID = (String) session.getAttribute("loginID");
        if (loginID == null) {
            logger.error("로그인된 사용자의 ID를 가져오지 못했습니다.");
            return "redirect:/zandi/login";
        }
        proj.setPrId(loginID);

        // 문자열을 Timestamp로 변환
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");
        Timestamp startDate = Timestamp.valueOf(LocalDateTime.parse(proj.getPrStartdate(), formatter));
        Timestamp endDate = Timestamp.valueOf(LocalDateTime.parse(proj.getPrEnddate(), formatter));

        proj.setPrStartdate(startDate.toString());
        proj.setPrEnddate(endDate.toString());

        logger.info("Converted Start Date: " + startDate);
        logger.info("Converted End Date: " + endDate);

        // 파일 업로드 처리 및 prImg 경로 설정
        if (files.length > 0) {
            String uploadFolder = request.getServletContext().getRealPath("/resources/upload/");
            String datePath = new SimpleDateFormat("yyyy/MM/dd").format(new Date()).replace("/", File.separator);
            File saveDir = new File(uploadFolder + File.separator + datePath);
            if (!saveDir.exists()) {
                saveDir.mkdirs();
            }

            for (int i = 0; i < files.length; i++) {
                MultipartFile file = files[i];
                if (!file.isEmpty()) {
                    String uploadFileName = UUID.randomUUID().toString() + "_" + file.getOriginalFilename();
                    File saveFile = new File(saveDir, uploadFileName);
                    try {
                        file.transferTo(saveFile);
                        logger.info("File uploaded successfully: " + saveFile.getAbsolutePath());
                        
                        // 첫 번째 파일에 대해서만 썸네일 생성
                        if (i == 0) {
                            String thumbnailFileName = "s_" + uploadFileName;
                            File thumbnailFile = new File(saveDir, thumbnailFileName);
                            BufferedImage bo_image = ImageIO.read(saveFile);
                            double ratio = 5.0;
                            int width = (int) (bo_image.getWidth() / ratio);
                            int height = (int) (bo_image.getHeight() / ratio);
                            BufferedImage bt_image = new BufferedImage(width, height, BufferedImage.TYPE_3BYTE_BGR);
                            Graphics2D graphic = bt_image.createGraphics();
                            graphic.drawImage(bo_image, 0, 0, width, height, null);
                            graphic.dispose();  // 리소스 해제
                            ImageIO.write(bt_image, "jpg", thumbnailFile);
                            proj.setPrImg("resources/upload/" + datePath + "/" + thumbnailFileName); // 썸네일 파일 경로 저장
                        }
                    } catch (IOException e) {
                        logger.error("파일 업로드 실패", e);
                        rttr.addFlashAttribute("message", "파일 업로드 실패");
                        return "redirect:/zandi/addProjectForm";
                    }
                } else {
                    logger.error("파일이 없습니다.");
                    rttr.addFlashAttribute("message", "파일을 선택해주세요.");
                    return "redirect:/zandi/addProjectForm";
                }
            }
        }

        adminService.projRegi(proj);
        rttr.addFlashAttribute("enroll_result", proj.getPrName());

        return "redirect:/zandiMainPage/MainPage.jsp"; 
    }
}