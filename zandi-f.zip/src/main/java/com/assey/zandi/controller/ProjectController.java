package com.assey.zandi.controller;

import com.assey.zandi.project.ProjectVO;
import com.assey.zandi.service.ProjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/zandi")
public class ProjectController {

    @Autowired
    private ProjectService projectService;

    @GetMapping("/search")
    public String searchProjects(@RequestParam("searchText") String searchText,
                                 @RequestParam(value = "pageNum", defaultValue = "1") int pageNum,
                                 Model model, HttpSession session) {
        String loginID = (String) session.getAttribute("loginID");

        int pageSize = 8; // 페이지 당 프로젝트 수
        int totalProjects = projectService.countSearchProjects(searchText); // 총 프로젝트 수
        int pageCount = (int) Math.ceil((double) totalProjects / pageSize);

        int offset = (pageNum - 1) * pageSize;
        List<ProjectVO> projectList = projectService.searchProjects(searchText, offset, pageSize);

        Map<Integer, Boolean> projectOwnership = new HashMap<>();
        for (ProjectVO project : projectList) {
            projectOwnership.put(project.getPrCode(), project.getPrId().equals(loginID));
        }

        // 페이징 그룹 설정
        int pageGroupSize = 5;
        int currentGroup = (int) Math.ceil((double) pageNum / pageGroupSize);
        int groupStartPage = (currentGroup - 1) * pageGroupSize + 1;
        int groupEndPage = Math.min(groupStartPage + pageGroupSize - 1, pageCount);

        model.addAttribute("projectList", projectList);
        model.addAttribute("currentPage", pageNum);
        model.addAttribute("pageCount", pageCount);
        model.addAttribute("groupStartPage", groupStartPage);
        model.addAttribute("groupEndPage", groupEndPage);
        model.addAttribute("searchText", searchText);
        model.addAttribute("projectOwnership", projectOwnership);
        model.addAttribute("loginID", loginID);

        if (projectList.isEmpty()) {
            model.addAttribute("message", "검색 결과가 없습니다.");
        }

        return "zandiProject/projectList";
    }
    
    
    
    @GetMapping("/myProjects")
    public String getMyProjects(HttpSession session,
                                @RequestParam(value = "pageNum", defaultValue = "1") int pageNum,
                                Model model) {
        String loginID = (String) session.getAttribute("loginID"); // 세션에서 로그인된 사용자의 ID를 가져옴

        if (loginID == null) {
            return "redirect:/zandiaccount/login.jsp"; // 로그인되지 않은 경우 로그인 페이지로 리다이렉트
        }

        int pageSize = 2; // 페이지 당 프로젝트 수
        int totalProjects = projectService.countProjectsByUsername(loginID); // 총 프로젝트 수
        int pageCount = (int) Math.ceil((double) totalProjects / pageSize);

        int offset = (pageNum - 1) * pageSize;
        List<ProjectVO> myProjects = projectService.findProjectsByUsername(loginID, offset, pageSize);

        // 페이징 그룹 설정
        int pageGroupSize = 5;
        int currentGroup = (int) Math.ceil((double) pageNum / pageGroupSize);
        int groupStartPage = (currentGroup - 1) * pageGroupSize + 1;
        int groupEndPage = Math.min(groupStartPage + pageGroupSize - 1, pageCount);

        model.addAttribute("myProjects", myProjects);
        model.addAttribute("currentPage", pageNum);
        model.addAttribute("pageCount", pageCount);
        model.addAttribute("groupStartPage", groupStartPage);
        model.addAttribute("groupEndPage", groupEndPage);

        return "zandiMypage/myProjects"; // myProjects.jsp로 데이터를 전달합니다.
    }

    
    @PostMapping("/myProjects/delete")
    public String deleteBookmark(@RequestParam("prCode") int prCode, HttpSession session) {
        String loginID = (String) session.getAttribute("loginID");

        if (loginID == null) {
            return "redirect:/login"; // 로그인되지 않은 경우 로그인 페이지로 리다이렉트
        }

        // 북마크 삭제 로직 수행
        projectService.deleteProject(prCode, loginID);

        
        return "redirect:/zandi/myProjects";
    }
    
    
    
    @GetMapping("/category")
    public String getProjectsByCategory(@RequestParam("category") String category,
                                        @RequestParam(value = "pageNum", defaultValue = "1") int pageNum,
                                        Model model) {
        int pageSize = 8;
        int totalProjects = projectService.countProjectsByCategory(category);
        int pageCount = (int) Math.ceil((double) totalProjects / pageSize);

        int offset = (pageNum - 1) * pageSize;
        List<ProjectVO> projectList = projectService.getProjectsByCategory(category, offset, pageSize);

        int pageGroupSize = 5;
        int currentGroup = (int) Math.ceil((double) pageNum / pageGroupSize);
        int groupStartPage = (currentGroup - 1) * pageGroupSize + 1;
        int groupEndPage = Math.min(groupStartPage + pageGroupSize - 1, pageCount);

        model.addAttribute("projectList", projectList);
        model.addAttribute("currentPage", pageNum);
        model.addAttribute("pageCount", pageCount);
        model.addAttribute("groupStartPage", groupStartPage);
        model.addAttribute("groupEndPage", groupEndPage);
        model.addAttribute("category", category);

        if (projectList.isEmpty()) {
            model.addAttribute("message", "해당 카테고리에 대한 프로젝트가 없습니다.");
        }

        return "/zandiProject/projectList";
    }
    
    
    @GetMapping("/allProjects")
    public String getAllProjects(@RequestParam(value = "pageNum", defaultValue = "1") int pageNum,
                                 Model model) {
        int pageSize = 8;
        int totalProjects = projectService.countAllProjects();
        int pageCount = (int) Math.ceil((double) totalProjects / pageSize);

        int offset = (pageNum - 1) * pageSize;
        List<ProjectVO> projectList = projectService.getAllProjects(offset, pageSize);

        int pageGroupSize = 5;
        int currentGroup = (int) Math.ceil((double) pageNum / pageGroupSize);
        int groupStartPage = (currentGroup - 1) * pageGroupSize + 1;
        int groupEndPage = Math.min(groupStartPage + pageGroupSize - 1, pageCount);

        model.addAttribute("projectList", projectList);
        model.addAttribute("currentPage", pageNum);
        model.addAttribute("pageCount", pageCount);
        model.addAttribute("groupStartPage", groupStartPage);
        model.addAttribute("groupEndPage", groupEndPage);

        return "/zandiProject/projectList";
    }
    
    @GetMapping("/projDetail")
    public String projectDetail(@RequestParam("prCode") int prCode, Model model) {
        ProjectVO project = projectService.getProjectByPrCode(prCode);
        model.addAttribute("project", project);
        return "/zandiMainPage/projDetail";
    }
    
}
