package com.assey.zandi.controller;

import com.assey.zandi.project.ProjectVO;
import com.assey.zandi.service.BookmarkService;
import com.assey.zandi.service.ProjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/zandi")
public class BookmarkController {

    @Autowired
    private BookmarkService bookmarkService;

    @Autowired
    private ProjectService projectService;

    @GetMapping("/bookmarkList")
    public String showBookmarkList(HttpSession session,
                                   @RequestParam(value = "pageNum", defaultValue = "1") String pageNumStr,
                                   Model model) {

        String loginID = (String) session.getAttribute("loginID");

        if (loginID == null) {
            return "redirect:/zandiaccount/login.jsp";
        }

        int pageSize = 5;
        int pageNum;

        try {
            pageNum = Integer.parseInt(pageNumStr);
        } catch (NumberFormatException e) {
            pageNum = 1;
        }

        int startRow = (pageNum - 1) * pageSize;

        List<ProjectVO> bookmarkedProjects = bookmarkService.getBookmarkedProjects(loginID, startRow, pageSize);
        int totalBookmarks = bookmarkService.getBookmarkedProjectCount(loginID);
        int pageCount = (int) Math.ceil((double) totalBookmarks / pageSize);

        int pageGroupSize = 5;
        int currentGroup = (int) Math.ceil((double) pageNum / pageGroupSize);
        int groupStartPage = (currentGroup - 1) * pageGroupSize + 1;
        int groupEndPage = Math.min(groupStartPage + pageGroupSize - 1, pageCount);

        model.addAttribute("bookmarkedProjects", bookmarkedProjects);
        model.addAttribute("currentPage", pageNum);
        model.addAttribute("pageCount", pageCount);
        model.addAttribute("groupStartPage", groupStartPage);
        model.addAttribute("groupEndPage", groupEndPage);

        return "zandiMypage/bookmarkList";
    }

    @PostMapping("/bookmark/delete")
    public String deleteBookmark(@RequestParam("prCode") int prCode, HttpSession session) {
        String loginID = (String) session.getAttribute("loginID");

        if (loginID == null) {
            return "redirect:/login";
        }

        bookmarkService.deleteBookmark(prCode, loginID);
        return "redirect:/zandi/bookmarkList";
    }

    @PostMapping("/bookmark/toggle")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> toggleBookmark(@RequestParam int prCode, HttpSession session) {
        String loginID = (String) session.getAttribute("loginID");


        Map<String, Object> response = new HashMap<>();
        if (loginID == null) {
            response.put("status", "not_logged_in");
            return ResponseEntity.ok(response);
        }

        boolean added = bookmarkService.toggleBookmark(loginID, prCode);
        response.put("status", added ? "added" : "removed");

        ProjectVO project = projectService.getProjectByPrCode(prCode);
        response.put("likeCount", project.getPrLikecount());
        response.put("isBookmarked", added);


        return ResponseEntity.ok().body(response);
    }

    @GetMapping("/projectList")
    public String getProjectList(Model model, HttpSession session) {
        String loginID = (String) session.getAttribute("loginID");

        List<ProjectVO> projectList = projectService.getAllProjects();

        Map<Integer, Boolean> projectOwnership = new HashMap<>();
        for (ProjectVO project : projectList) {
            projectOwnership.put(project.getPrCode(), project.getPrId().equals(loginID));
        }

        model.addAttribute("projectList", projectList);
        model.addAttribute("projectOwnership", projectOwnership);
        model.addAttribute("loginID", loginID);
        return "zandiProject/projectList";
    }
    
    @GetMapping("/getUserBookmarkedProjects")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> getUserBookmarkedProjects(@RequestParam("loginID") String loginID) {
        Map<String, Object> response = new HashMap<>();
        if (loginID == null) {
            response.put("userBookmarkedProjectCodes", Collections.emptyList());
        } else {
            List<Integer> userBookmarkedProjectCodes = bookmarkService.getUserBookmarkedProjectCodes(loginID);
            response.put("userBookmarkedProjectCodes", userBookmarkedProjectCodes);
        }
        return ResponseEntity.ok().body(response);
    }
}

