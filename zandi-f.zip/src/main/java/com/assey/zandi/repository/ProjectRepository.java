package com.assey.zandi.repository;

import com.assey.zandi.project.ProjectVO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

import javax.transaction.Transactional;

@Repository
public interface ProjectRepository extends JpaRepository<ProjectVO, Integer> {
    Page<ProjectVO> findByPrNameContainingOrPrDescriptionContaining(String prName, String prDescription, Pageable pageable);
    long countByPrNameContainingOrPrDescriptionContaining(String prName, String prDescription);
    List<ProjectVO> findByPrId(String prId);
    
    // 사용자별 프로젝트 페이징 메서드
    Page<ProjectVO> findByPrId(String prId, Pageable pageable);
    
    // 사용자별 프로젝트 총 개수를 계산하는 메서드
    long countByPrId(String prId);
    
    // 프로젝트 삭제 메서드
    @Transactional
    void deleteByPrCodeAndPrId(int prCode, String prId);
    
    
    
    Page<ProjectVO> findByPrCategory(String prCategory, Pageable pageable);
    long countByPrCategory(String prCategory);
    
}