function sample6_execDaumPostcode() {
    new daum.Postcode({
        oncomplete: function(data) {
            var addr = ''; // 주소 변수

            // 사용자가 선택한 주소 타입에 따라 해당 주소 값을 가져온다.
            if (data.userSelectedType === 'R') { // 사용자가 도로명 주소를 선택했을 경우
                addr = data.roadAddress;
            } else { // 사용자가 지번 주소를 선택했을 경우(J)
                addr = data.jibunAddress;
            }
            // 우편번호와 주소 정보를 해당 필드에 넣는다.
            document.getElementById('memPost').value = data.zonecode;
            document.getElementById("memAddress").value = addr;
            // 커서를 상세주소 필드로 이동한다.
            document.getElementById("memSaddress").focus();
        }
    }).open();
}

function updateCheck() {
    var form = document.forms['regForm'];
    var memNickname = form['memNickname'].value.trim();
    var memPw = form['memPw'].value.trim();
    var repass = form['repass'].value.trim();
    var memMail = form['memMail'].value.trim();
    var memPost = form['memPost'].value.trim();
    var memAddress = form['memAddress'].value.trim();
    var memSaddress = form['memSaddress'].value.trim();

    // 비밀번호 검사
    if (memPw === "") {
        alert("비밀번호를 입력해 주세요.");
        form['memPw'].focus();
        return false;
    }

    if (memPw.length < 8 || memPw.length > 15) {
        alert("비밀번호는 8자에서 15자 사이여야 합니다.");
        form['memPw'].focus();
        return false;
    }

    if (!/[a-zA-Z]/.test(memPw) || !/[0-9]/.test(memPw) || !/[~!@#$%^&*()_+]/.test(memPw)) {
        alert("비밀번호는 영문, 숫자, 특수문자(~!@#$%^&*()_+)를 포함해야 합니다.");
        form['memPw'].focus();
        return false;
    }

    if (repass === "") {
        alert("비밀번호 확인을 입력해 주세요.");
        form['repass'].focus();
        return false;
    }

    if (memPw !== repass) {
        alert("비밀번호가 일치하지 않습니다.");
        form['repass'].focus();
        return false;
    }

    // 닉네임 검사
    if (memNickname === "") {
        alert("닉네임을 입력하세요.");
        form['memNickname'].focus();
        return false;
    }

    if (memNickname.length < 2) {
        alert("닉네임은 최소 2글자 이상이어야 합니다.");
        form['memNickname'].focus();
        return false;
    }

    // 이메일 검사
    if (memMail === "") {
        alert("이메일을 입력해 주세요.");
        form['memMail'].focus();
        return false;
    }

    // 이메일 형식 검사
    var str = memMail;
    var atPos = str.indexOf('@');
    var atLastPos = str.lastIndexOf('@');
    var dotPos = str.indexOf('.');
    var spacePos = str.indexOf(' ');
    var commaPos = str.indexOf(',');
    var eMailSize = str.length;

    if (!(atPos > 1 && atPos === atLastPos && dotPos > 3 && spacePos === -1 && commaPos === -1 && atPos + 1 < dotPos && dotPos + 1 < eMailSize)) {
        alert("E mail 주소 형식이 잘못되었습니다. \n\r 다시 입력해 주세요.");
        form['memMail'].focus();
        return false;
    }

    // 우편번호 검사
    if (memPost === "") {
        alert("우편 번호를 입력해 주세요.");
        form['memPost'].focus();
        return false;
    }

    // 주소 검사
    if (memAddress === "") {
        alert("주소를 입력해 주세요.");
        form['memAddress'].focus();
        return false;
    }

    // 상세주소 검사
    if (memSaddress === "") {
        alert("상세주소를 입력해 주세요.");
        form['memSaddress'].focus();
        return false;
    }

    return true; // 모든 입력이 유효한 경우 true 반환
}