package com.assey.zandi.project;

public class PaymentVO {

}
