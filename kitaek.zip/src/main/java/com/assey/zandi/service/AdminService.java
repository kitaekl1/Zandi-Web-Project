package com.assey.zandi.service;

import com.assey.zandi.project.ProjectVO;

public interface AdminService {
    void projRegi(ProjectVO proj);
}