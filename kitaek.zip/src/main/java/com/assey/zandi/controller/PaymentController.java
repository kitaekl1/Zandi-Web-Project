package com.assey.zandi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.io.IOException;

@Controller
@RequestMapping("/payment")
public class PaymentController {
    @Autowired
    private PortOneClient portOneClient;

    @GetMapping("/form")
    public ModelAndView showForm() {
        return new ModelAndView("paymentForm");
    }

    @PostMapping("/request")
    @ResponseBody
    public String requestPayment(@RequestParam String merchantUid, @RequestParam String amount, @RequestParam String buyerName) {
        PaymentRequest paymentRequest = new PaymentRequest();
        paymentRequest.setMerchantUid(merchantUid);
        paymentRequest.setAmount(amount);
        paymentRequest.setBuyerName(buyerName);

        try {
            String token = portOneClient.getToken();
            return portOneClient.requestPayment(token, paymentRequest);
        } catch (IOException e) {
            e.printStackTrace();
            return "Error occurred while processing payment";
        }
    }
}
